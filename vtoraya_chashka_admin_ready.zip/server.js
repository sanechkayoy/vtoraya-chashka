const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const root = __dirname;
const dataPath = path.join(root, 'data', 'db.json');
const PORT = 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'VtorayaChashka2026!';
const sessions = new Map();
const SESSION_TTL = 2 * 60 * 60 * 1000;

const mime = { '.html':'text/html', '.css':'text/css', '.js':'application/javascript', '.json':'application/json', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.svg':'image/svg+xml', '.webp':'image/webp', '.ico':'image/x-icon' };

function send(res, code, type, body, headers={}) {
  res.writeHead(code, {'Content-Type': `${type}; charset=utf-8`, 'Cache-Control':'no-store', ...headers});
  res.end(body);
}
function readData(){ try{return JSON.parse(fs.readFileSync(dataPath,'utf8'));}catch{return {settings:{},menu:[],reviews:[]};} }
function saveData(d){fs.mkdirSync(path.dirname(dataPath),{recursive:true});fs.writeFileSync(dataPath,JSON.stringify(d,null,2),'utf8');}
function parseCookies(req){const out={};(req.headers.cookie||'').split(';').forEach(x=>{const i=x.indexOf('=');if(i>0)out[x.slice(0,i).trim()]=decodeURIComponent(x.slice(i+1).trim());});return out;}
function session(req){const t=parseCookies(req).admin_session;const s=t&&sessions.get(t);if(!s)return null;if(Date.now()>s.expires){sessions.delete(t);return null;}s.expires=Date.now()+SESSION_TTL;return {token:t,...s};}
function isAdmin(req){return !!session(req);}
function same(a,b){const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length&&crypto.timingSafeEqual(x,y);}
function body(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>5e6)reject(new Error('too large'));});req.on('end',()=>{try{resolve(JSON.parse(b||'{}'));}catch(e){reject(e);}});req.on('error',reject);});}
function htmlEscape(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');}

function loginPage(error='') { return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Вход — Вторая Чашка</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f4eee6;color:#2d211a;font-family:Inter,Arial,sans-serif}.card{width:min(420px,calc(100% - 28px));background:#fff;border:1px solid #e4d9cc;border-radius:24px;padding:34px;box-shadow:0 25px 70px rgba(55,35,20,.12)}.logo{width:54px;height:54px;border-radius:16px;background:#3c281d;color:#fff;display:grid;place-items:center;font-size:25px;margin-bottom:22px}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.14em;color:#9a826f;font-weight:800}.card h1{font:400 38px Georgia,serif;margin:8px 0}.muted{color:#88786d;line-height:1.55}.label{display:block;margin:24px 0 8px;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#69564a}input{width:100%;padding:14px 15px;border:1px solid #d9ccbd;border-radius:12px;font-size:16px;outline:none}input:focus{border-color:#7b563d;box-shadow:0 0 0 3px #7b563d18}button{width:100%;margin-top:16px;border:0;border-radius:12px;padding:14px;background:#3c281d;color:#fff;font-weight:800;font-size:15px;cursor:pointer}.error{margin-top:14px;padding:11px 12px;border-radius:10px;background:#fff0ed;color:#a33d2d;font-size:13px}</style></head><body><form class="card" method="post" action="/api/admin/login"><div class="logo">☕</div><div class="eyebrow">Вторая Чашка</div><h1>Личный кабинет</h1><p class="muted">Управляйте меню, ценами и информацией о кофейне без изменения кода.</p><label class="label">Пароль администратора</label><input name="password" type="password" autocomplete="current-password" autofocus required placeholder="Введите пароль"><button>Войти в админку</button>${error?`<div class="error">${htmlEscape(error)}</div>`:''}</form></body></html>`;}

async function login(req,res){let raw='';req.on('data',c=>raw+=c);await new Promise((resolve,reject)=>{req.on('end',resolve);req.on('error',reject);});const p=new URLSearchParams(raw);if(!same(p.get('password'),ADMIN_PASSWORD))return send(res,401,'text/html',loginPage('Неверный пароль. Попробуйте ещё раз.'));const token=crypto.randomBytes(32).toString('hex');sessions.set(token,{expires:Date.now()+SESSION_TTL});res.writeHead(302,{Location:'/admin', 'Set-Cookie':`admin_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_TTL/1000}`});res.end();}
function logout(req,res){const s=session(req);if(s)sessions.delete(s.token);res.writeHead(302,{Location:'/admin','Set-Cookie':'admin_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'});res.end();}
function serve(res,file){if(fs.existsSync(file)&&fs.statSync(file).isFile())return send(res,200,mime[path.extname(file).toLowerCase()]||'text/plain',fs.readFileSync(file));return send(res,404,'text/plain','Not found');}

const server=http.createServer(async(req,res)=>{try{const u=new URL(req.url,`http://${req.headers.host||'localhost'}`);const p=u.pathname;
  if(p==='/api/admin/login'&&req.method==='POST')return login(req,res);
  if(p==='/api/admin/logout'&&req.method==='POST')return logout(req,res);
  if(p==='/logout')return logout(req,res);
  if(p==='/api/data'&&req.method==='GET')return send(res,200,'application/json',JSON.stringify(readData()));
  if(p==='/api/save'&&req.method==='POST'){if(!isAdmin(req))return send(res,401,'application/json',JSON.stringify({ok:false,error:'Unauthorized'}));try{saveData(await body(req));return send(res,200,'application/json',JSON.stringify({ok:true}));}catch{return send(res,400,'application/json',JSON.stringify({ok:false,error:'Invalid data'}));}}
  if(p==='/admin'||p==='/admin.html'){if(!isAdmin(req))return send(res,200,'text/html',loginPage());return serve(res,path.join(root,'admin.html'));}
  if(p==='/')return serve(res,path.join(root,'public','index.html'));
  if(p.startsWith('/public/'))return serve(res,path.join(root,p));
  return serve(res,path.join(root,p));
}catch(e){console.error(e);return send(res,500,'text/plain','Server error');}});
setInterval(()=>{const now=Date.now();for(const [t,s] of sessions)if(now>s.expires)sessions.delete(t);},10*60*1000);
server.listen(PORT,()=>console.log(`Сайт: http://localhost:${PORT}\nАдминка: http://localhost:${PORT}/admin\nПароль: ${ADMIN_PASSWORD}\n`));
